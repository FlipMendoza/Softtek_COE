Required files for knife docker image to be properly built
* admin.pem
* chef-server.crt - Name convention may change depending on your chef server's hostname
* chef-validator.pem
* chef-webui.pem
* user's name already registered in chef server (jenkins.pem)
* knife.rb - Configuration file created during knife's local configuration