It is required to have mute.sh within the same folder while building chef server's docker image,
this because mentioned bash script allows chef server to successfuly execute its commands as per required
and at the same time not allowing docker container to die as it shows all logs