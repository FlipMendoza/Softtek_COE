sqlplus64 system/LetsDocker@sql-server:1521/ORCLPDB1 << EOF
SELECT * FROM demo_qa_env;
exit;
EOF