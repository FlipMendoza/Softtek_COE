oracle-client Cookbook CHANGELOG
========================
v0.3.0
Added properties to allow individual templates to be overriden in a wrapper cookbook.

v0.2.0
Update cookbook to use the compat_resource/custom resource from Chef 12.5.

v0.1.0
Initial release.
